// src/App.js
import React from 'react';
import Form from './Form';

const App = () => {
  return (
    <div className="App">
      <h1>Form Validation </h1>
      <Form />
    </div>
  );
};

export default App;
